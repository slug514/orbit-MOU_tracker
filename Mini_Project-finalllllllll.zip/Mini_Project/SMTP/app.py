from flask import Flask, render_template
from flask_apscheduler import APScheduler
from datetime import datetime
import smtplib
from email.mime.text import MIMEText
import gspread
from oauth2client.service_account import ServiceAccountCredentials

app = Flask(__name__)

class Config:
    SCHEDULER_API_ENABLED = True

app.config.from_object(Config())
scheduler = APScheduler()
scheduler.init_app(app)


SCOPES = ['https://spreadsheets.google.com/feeds', 'https://www.googleapis.com/auth/drive']
SHEET_NAME = 'MOU_Data' 
SHEET_RANGE_COL = 2   


SPREADSHEET_ID = '1HdwE7Jyz0Dp9A5koVkSVrJbt8gxjNCSg_G5FETKo04w'


def get_google_sheet_data():
    try:
        creds = ServiceAccountCredentials.from_json_keyfile_name('credentials.json', SCOPES)
        client = gspread.authorize(creds)
        sheet = client.open(SHEET_NAME).sheet1
        emails = sheet.col_values(SHEET_RANGE_COL)[1:]  
        return emails
    except Exception as e:
        print(f"Error accessing Google Sheet: {e}")
        return []


def send_email(to_email, subject, body_html):
    from_email = "orbitmoutracker@gmail.com"
    app_password = "qjwe gjeg uwfb vusc" 

    msg = MIMEText(body_html, "html")
    msg["Subject"] = subject
    msg["From"] = from_email
    msg["To"] = to_email

    try:
        server = smtplib.SMTP("smtp.gmail.com", 587)
        server.starttls()
        server.login(from_email, app_password)
        server.send_message(msg)
        server.quit()
        print(f"[{datetime.now()}] Email sent to {to_email}")
    except Exception as e:
        print(f"Error sending email: {e}")


def send_reminder():
    print(f"[{datetime.now()}] Running scheduled reminder...")
    emails = get_google_sheet_data()
    for email in emails:
        body_html = """
        <p>It's been a while since you last logged in.</p>
        <p>Please click the button below to visit your MOUTracker account:</p>
        <a href="http://localhost:5000/login"
           style="display: inline-block; padding: 10px 20px;
                  background-color: #00F0FF; color: #000; text-decoration: none;
                  border-radius: 5px; font-weight: bold;">
           Login Now
        </a>
        """
        send_email(email, "MOU Reminder", body_html)

@app.route('/')
def index():
    return render_template('send_mail_form.html')  


if __name__ == '__main__':
    scheduler.add_job(
        id='send_reminder_task',
        func=send_reminder,
        trigger='interval',
        minutes=5,  
        next_run_time=datetime.now()
    )
    scheduler.start()
    app.run(debug=True, use_reloader=False)