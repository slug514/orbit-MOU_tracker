import pdfkit
from flask import Flask, render_template, request, send_file
from io import BytesIO


config = pdfkit.configuration(wkhtmltopdf=r"C:\Program Files\wkhtmltopdf\bin\wkhtmltopdf.exe")

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')
@app.route('/generate', methods=['POST'])
def generate_pdf():
    data = request.form.to_dict()
    html_out = render_template("mou_template.html", **data)
    pdf = pdfkit.from_string(html_out, False, configuration=config)

    return send_file(
        BytesIO(pdf),
        as_attachment=True,
        download_name="MOU.pdf",
        mimetype="application/pdf"
    )

if __name__ == '__main__':
    app.run(debug=True)
