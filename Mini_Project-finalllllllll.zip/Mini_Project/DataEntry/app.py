from flask import Flask, request
from flask import render_template
import gspread
from oauth2client.service_account import ServiceAccountCredentials
import smtplib
from email.mime.text import MIMEText
import os
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload
from google.oauth2 import service_account

app = Flask(__name__)
UPLOAD_FOLDER = 'uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)


def upload_to_drive(file_path, filename):
    SCOPES = ['https://www.googleapis.com/auth/drive']
    creds = service_account.Credentials.from_service_account_file('credentials.json', scopes=SCOPES)

    service = build('drive', 'v3', credentials=creds)

    
    folder_id = '1aRRLcK9BE6untPhheqlriAN8_zc6Z_uT'  

    file_metadata = {
        'name': filename,
        'parents': [folder_id] if folder_id else []
    }
    media = MediaFileUpload(file_path, resumable=True)

    uploaded_file = service.files().create(body=file_metadata, media_body=media, fields='id').execute()
    print(f"File uploaded to Google Drive with ID: {uploaded_file.get('id')}")
    return uploaded_file.get('id')

def save_to_sheet(data):
    scope = ['https://spreadsheets.google.com/feeds', 'https://www.googleapis.com/auth/drive']
    creds = ServiceAccountCredentials.from_json_keyfile_name('credentials.json', scope)
    client = gspread.authorize(creds)

    sheet = client.open("MOU_Data").sheet1
    sheet.append_row(data)


def send_email(body, attachment_path, attachment_name,to_email):
    from_email = "orbitmoutracker@gmail.com"
    app_password = "qjwe gjeg uwfb vusc"
    to_email = to_email

   
    msg = MIMEMultipart()
    msg['Subject'] = "New MOU Form Submission"
    msg['From'] = from_email
    msg['To'] = to_email

    
    msg.attach(MIMEText(body, 'plain'))

   
    with open(attachment_path, "rb") as f:
        part = MIMEApplication(f.read(), Name=attachment_name)
        part['Content-Disposition'] = f'attachment; filename="{attachment_name}"'
        msg.attach(part)

    
    try:
        server = smtplib.SMTP("smtp.gmail.com", 587)
        server.starttls()
        server.login(from_email, app_password)
        server.send_message(msg)
        server.quit()
        print(f"Email sent to {to_email} with attachment")
    except Exception as e:
        print(f"Email error: {e}")

@app.route('/')
def index():
    return render_template("send_mail_form.html")


@app.route("/submit-mou", methods=["POST"])
def submit_mou():
    f = request.files["mou_document"]
    doc_path = os.path.join(UPLOAD_FOLDER, f.filename)
    f.save(doc_path)
    drive_file_id = upload_to_drive(doc_path, f.filename)
    drive_link = f"https://drive.google.com/file/d/{drive_file_id}/view"
    
    institute_name = request.form["institute_name"]
    institute_mail = request.form["institute_mail"]
    years = request.form["mou_years"]
    months = request.form["mou_months"]
    duration = f"{years} years, {months} months"
    faculty = request.form["faculty_signatory"]
    faculty_mail = request.form["faculty_details"]
    year = request.form["academic_year"]
    purpose = request.form["purpose"]
    outcomes = request.form["outcomes"]

    
    save_to_sheet([institute_name, institute_mail, duration, f.filename, faculty, faculty_mail, year, purpose, outcomes, drive_link])

    
    email_body = f"""
    New MOU Submission

    Institute: {institute_name}
    Duration: {duration}
    Faculty: {faculty}
    Faculty Details: {faculty_mail}
    Academic Year: {year}
    Purpose: {purpose}
    Outcomes: {outcomes}
    Document: {f.filename}
    """
    send_email(email_body, doc_path, f.filename,institute_mail)


    return "Form submitted and email sent!"

if __name__ == "__main__":
    app.run(debug=True,port=8000)
