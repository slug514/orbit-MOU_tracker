const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const axios = require('axios'); 
const app = express();
const port = 3000;


app.use(cors());


app.use(bodyParser.json());


const scriptURL = 'https://script.google.com/macros/s/AKfycbzaMlBTXfFeUSoaMLRJpcgOpIyow-SBmQsFBd2afR1n3C8lqIyRQzkCr4b5bd3OU5Jh/exec';


const sendRequestToGoogleScript = async (action, username, password, email = '',newPassword) => {
  const data = {
    action,
    username,
    password,
    email,
    newPassword
  };

  try {
    const response = await axios.post(scriptURL, data);
    return response;
  } catch (error) {
    console.error('Error while sending data to Google Apps Script:', error);
    throw new Error('Failed to communicate with Google Apps Script');
  }
};


app.post('/api/submit', async (req, res) => {
  try {
    console.log('Request body:', req.body); 

    const { action, username, password, email, newPassword } = req.body;
    
    

    let response;

    
    if (action === 'signup') {
      if (!email) {
        return res.status(400).json({ status: 'error', message: 'Email is required for signup' });
      }
      response = await sendRequestToGoogleScript(action, username, password, email);
    }
    
    else if (action === 'login') {
      response = await sendRequestToGoogleScript(action, username, password);
    }
    
    else if (action === 'reset') {
      if (!email) {
        return res.status(400).json({ status: 'error', message: 'Email is required for reset' });
      }
      response = await sendRequestToGoogleScript(action, username, password, email); // Reset only needs email
    }
    else if (action === 'updatePassword') {
        response = await sendRequestToGoogleScript(action, username, password, email, newPassword);
    }
    
    else {
      return res.status(400).json({ status: 'error', message: 'Invalid action' });
    }

    
    if (response.status !== 200) {
      console.error('Error response from Google Apps Script:', response.data);
      return res.status(400).json({ status: 'error', message: 'Failed to process request' });
    }

    if(response.data.status==='success'){
        return res.status(200).json(response.data)
    }
    else if(response.data.status==='fail'){
        return res.status(400).json(response.data)
    }

  } catch (error) {
    console.error('Server error:', error); 
    res.status(500).json({ status: 'error', message: 'Internal server error' });
  }
});


app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});
