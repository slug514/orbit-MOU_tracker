const express = require('express');
const axios = require('axios');
const cors = require('cors');
const app = express();

app.use(cors());
const PORT = 3100;


const SCRIPT_URL = 'https://script.google.com/macros/s/AKfycbzBozvaelyeA3r0siUvAQMPsFNb7YSGBZGvXKyxjuKMfVRhZqebto2I1gNhBz7rwdpw/exec';

app.get('/api/search', async (req, res) => {
  try {
    const queryParam = new URLSearchParams(req.query).toString();
    const url = `${SCRIPT_URL}?${queryParam}`;
    const response = await axios.get(url);
    res.json(response.data); 
  } catch (err) {
    console.error('Axios error:', err.message);
    res.status(500).json({ error: 'Something went wrong' });
  }
});

app.listen(PORT, () => console.log(`Server running at http://localhost:${PORT}`));


